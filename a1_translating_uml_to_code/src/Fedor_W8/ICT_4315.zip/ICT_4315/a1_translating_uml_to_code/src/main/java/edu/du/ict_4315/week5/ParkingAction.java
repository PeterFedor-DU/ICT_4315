package edu.du.ict_4315.week5;

public interface ParkingAction {
    void update(ParkingEvent event);
}
