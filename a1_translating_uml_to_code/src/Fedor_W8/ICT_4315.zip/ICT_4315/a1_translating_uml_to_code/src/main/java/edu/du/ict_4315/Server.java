package edu.du.ict_4315;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Properties;

public class Server {
    private static final int PORT = 8000;

    public static void main(String[] args) {
        System.out.println("Starting server...");
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                try (Socket clientSocket = serverSocket.accept();
                     BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                     PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {

                    System.out.println("Client connected.");

                    String inputLine = in.readLine();
                    System.out.println("Received: " + inputLine);

                    ParkingRequest request = ParkingRequest.fromJson(inputLine);
                    Properties props = request.getParameters();
                    String command = request.getCommandName();

                    ParkingResponse response;
                    if ("CUSTOMER".equalsIgnoreCase(command)) {
                        response = new ParkingResponse(200, "Customer registered: " + props.getProperty("firstname"));
                    } else if ("CAR".equalsIgnoreCase(command)) {
                        response = new ParkingResponse(200, "Car registered: " + props.getProperty("license"));
                    } else {
                        response = new ParkingResponse(400, "Unknown command: " + command);
                    }

                    out.println(response.toJson());
                    out.println("end");

                    System.out.println("Response sent, connection closing.");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            System.err.println("Server startup failed: " + e.getMessage());
        }
    }
}