package edu.du.ict_4315.strategy;

import java.time.LocalDateTime;

import edu.du.ict_4315.Money;
import edu.du.ict_4315.ParkingPermit;

public interface ParkingChargeStrategy {
    Money calculateCharge(ParkingPermit permit, LocalDateTime entryTime, LocalDateTime exitTime, Money baseRate);
}
