package edu.du.ict_4315.decorator;

import java.time.LocalDateTime;

import edu.du.ict_4315.Money;
import edu.du.ict_4315.ParkingLot;
import edu.du.ict_4315.ParkingPermit;

public class FlatRateCalculator extends ParkingChargeCalculator {

    private static final Money FLAT_RATE = new Money(10.00);

    @Override
    public Money getParkingCharge(LocalDateTime entryTime, LocalDateTime exitTime,
                                  ParkingLot lot, ParkingPermit permit) {
        return FLAT_RATE;
    }
}
