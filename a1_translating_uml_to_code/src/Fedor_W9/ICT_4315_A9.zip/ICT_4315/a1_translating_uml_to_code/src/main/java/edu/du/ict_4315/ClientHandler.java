package edu.du.ict_4315;

import java.io.*;
import java.net.Socket;
import java.util.Properties;

public class ClientHandler implements Runnable {

    private final Socket clientSocket;

    public ClientHandler(Socket socket) {
        this.clientSocket = socket;
    }

    @Override
    public void run() {
        long startTime = System.currentTimeMillis();
        String clientAddress = clientSocket.getInetAddress().getHostAddress();
        System.out.println("[Connected] Client from " + clientAddress);

        try (
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)
        ) {
            String inputLine = in.readLine();
            System.out.println("[Received] From " + clientAddress + ": " + inputLine);

            ParkingRequest request = ParkingRequest.fromJson(inputLine);
            Properties props = request.getParameters();
            String command = request.getCommandName();

            ParkingResponse response;
            if ("CUSTOMER".equalsIgnoreCase(command)) {
                response = new ParkingResponse(200, "Customer registered: " + props.getProperty("firstname"));
            } else if ("CAR".equalsIgnoreCase(command)) {
                response = new ParkingResponse(200, "Car registered: " + props.getProperty("license"));
            } else {
                response = new ParkingResponse(400, "Unknown command: " + command);
            }

            out.println(response.toJson());
            out.println("end");

        } catch (Exception e) {
            System.err.println("[Error] Handling client from " + clientAddress + ": " + e.getMessage());
        } finally {
            try {
                clientSocket.close();
            } catch (IOException ignored) {}

            long endTime = System.currentTimeMillis();
            long duration = endTime - startTime;
            System.out.println("[Disconnected] Client from " + clientAddress + " | Time handled: " + duration + " ms");
        }
    }
}