package edu.du.ict_4315.week5;

import edu.du.ict_4315.TransactionManager;
import edu.du.ict_4315.ParkingLot;

public class ParkingObserver implements ParkingAction {
    private final TransactionManager manager;

    public ParkingObserver(TransactionManager manager) {
        this.manager = manager;
    }

    @Override
    public void update(ParkingEvent event) {
        if (event.isEntry()) { 
            manager.park(event);
        }
    }

	public void handleParkingEvent(ParkingEvent event) {
		// TODO Auto-generated method stub
		
	}
}
