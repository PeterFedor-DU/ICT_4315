package edu.du.ict_4315.week5;

import java.time.LocalDateTime;

import edu.du.ict_4315.ParkingLot;
import edu.du.ict_4315.ParkingPermit;

public class ParkingEvent {
    private final ParkingPermit permit;
    private final ParkingLot lot;
    private final LocalDateTime timestamp;
    private final boolean isEntry;

    public ParkingEvent(ParkingPermit localDateTime, ParkingLot string, boolean parkingLot) {
        this.permit = localDateTime;
        this.lot = string;
        this.timestamp = LocalDateTime.now();
        this.isEntry = parkingLot;
    }

    public ParkingEvent(LocalDateTime now, String permit2, ParkingLot parkingLot) {
		this.permit = null;
		this.lot = null;
		this.timestamp = null;
		this.isEntry = true ;
	}

	public ParkingPermit getPermit() { return permit; }
    public ParkingLot getLot() { return lot; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public boolean isEntry() { return isEntry; }
}
