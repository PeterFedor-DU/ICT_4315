package edu.du.ict_4315.decorator;

import java.time.LocalDateTime;

import edu.du.ict_4315.Money;
import edu.du.ict_4315.ParkingLot;
import edu.du.ict_4315.ParkingPermit;

public abstract class ParkingChargeCalculator {
    public abstract Money getParkingCharge(LocalDateTime entryTime, LocalDateTime exitTime,
                                           ParkingLot lot, ParkingPermit permit);
}
