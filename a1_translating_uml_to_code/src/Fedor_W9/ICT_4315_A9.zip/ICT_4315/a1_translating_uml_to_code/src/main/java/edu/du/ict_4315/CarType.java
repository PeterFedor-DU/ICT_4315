package edu.du.ict_4315;

public enum CarType {
    COMPACT, SUV
}
