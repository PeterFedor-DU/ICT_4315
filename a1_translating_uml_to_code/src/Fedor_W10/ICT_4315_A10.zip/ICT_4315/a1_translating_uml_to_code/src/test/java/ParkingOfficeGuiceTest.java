package edu.du.ict_4315;

import static org.junit.jupiter.api.Assertions.*;

import com.google.inject.Guice;
import com.google.inject.Injector;
import java.util.Calendar;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ParkingOfficeGuiceTest {

    private ParkingOffice parkingOffice;

    @BeforeEach
    public void setUp() {
        Injector injector = Guice.createInjector(new ParkingSystemModule());
        parkingOffice = injector.getInstance(ParkingOffice.class);
    }

    @Test
    public void testInjectionNotNull() {
        assertNotNull(parkingOffice);
    }

    @Test
    public void testRegisterCustomerAndCar() {
        Customer customer = parkingOffice.register("C001", "Peter Fedor", new Address("321 Asbury St"), "555-1234");
        assertNotNull(customer);
        assertEquals("C001", customer.getCustomerId());

        Car car = new Car("ABC123", CarType.COMPACT, customer);
        ParkingPermit permit = parkingOffice.register(car);
        assertNotNull(permit);
        assertEquals("PERMIT-ABC123", permit.getId());
    }

    @Test
    public void testParkingTransactionAndCharges() {
        Customer customer = parkingOffice.register("C002", "Cindy Le", new Address("123 Asbury St"), "555-5678");
        Car car = new Car("TOFT12", CarType.SUV, customer);
        ParkingPermit permit = parkingOffice.register(car);

   
        ParkingLot lot = new ParkingLot("Lot1", 5.0); 
        parkingOffice.addParkingLot(lot);

        Calendar now = Calendar.getInstance();
        ParkingTransaction transaction = parkingOffice.park(now, permit, lot);
        assertNotNull(transaction);
        assertEquals(permit, transaction.getPermit());

        Money chargesByPermit = parkingOffice.getParkingCharges(permit);
        assertTrue(chargesByPermit.getAmount() >= 0);

        Money chargesByCustomer = parkingOffice.getParkingCharges(customer);
        assertTrue(chargesByCustomer.getAmount() >= 0);
    }
}