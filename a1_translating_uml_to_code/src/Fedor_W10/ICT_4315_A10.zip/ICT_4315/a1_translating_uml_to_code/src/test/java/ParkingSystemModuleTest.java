package edu.du.ict_4315;

import static org.junit.jupiter.api.Assertions.*;

import com.google.inject.Guice;
import com.google.inject.Injector;
import org.junit.jupiter.api.Test;

public class ParkingSystemModuleTest {

    @Test
    public void testGuiceBindings() {
        Injector injector = Guice.createInjector(new ParkingSystemModule());

        IPermitManager permitManager = injector.getInstance(IPermitManager.class);
        ITransactionManager transactionManager = injector.getInstance(ITransactionManager.class);

        assertNotNull(permitManager);
        assertNotNull(transactionManager);
        assertEquals(PermitManager.class, permitManager.getClass());
        assertEquals(TransactionManager.class, transactionManager.getClass());
    }
}