package edu.du.ict_4315;

import com.google.inject.Singleton;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Singleton
public class PermitManager implements IPermitManager {
    private HashMap<String, ParkingPermit> permits;

    public PermitManager() {
        this.permits = new HashMap<>();
    }

    public ParkingPermit register(Car car) {
        String permitId = "PERMIT-" + car.getLicense();
        if (permits.containsKey(permitId)) {
            return permits.get(permitId);  
        }

        ParkingPermit permit = new ParkingPermit(permitId, car);
        permits.put(permitId, permit);
        return permit;
    }

    @Override
    public List<String> getAllPermitIds() {
        return new ArrayList<>(permits.keySet());
    }

    @Override
    public List<String> getPermitIdsByCustomer(Customer customer) {
        List<String> permitIds = new ArrayList<>();
        for (ParkingPermit permit : permits.values()) {
            if (permit.getCar().getOwner().equals(customer)) {
                permitIds.add(permit.getId());
            }
        }
        return permitIds;
    }
}
