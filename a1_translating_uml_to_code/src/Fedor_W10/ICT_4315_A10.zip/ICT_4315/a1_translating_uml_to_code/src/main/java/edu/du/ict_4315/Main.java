package edu.du.ict_4315;

import com.google.inject.Guice;
import com.google.inject.Injector;

public class Main {
    public static void main(String[] args) {
        Injector injector = Guice.createInjector(new ParkingSystemModule());
        ParkingOffice office = injector.getInstance(ParkingOffice.class);
         
    }
}