package edu.du.ict_4315;

import com.google.inject.AbstractModule;

public class ParkingSystemModule extends AbstractModule {
    @Override
    protected void configure() {
        bind(IPermitManager.class).to(PermitManager.class);
        bind(ITransactionManager.class).to(TransactionManager.class);
    }
}