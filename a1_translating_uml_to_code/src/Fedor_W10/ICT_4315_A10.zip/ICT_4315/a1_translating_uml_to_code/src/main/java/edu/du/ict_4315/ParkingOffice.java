package edu.du.ict_4315;

import com.google.inject.Inject;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ParkingOffice {
    private String parkingOfficeName;
    private List<Customer> customers;
    private List<ParkingLot> parkingLots;
    private IPermitManager permitManager;
    private ITransactionManager transactionManager;

    @Inject
    public ParkingOffice(IPermitManager permitManager, ITransactionManager transactionManager) {
        this.parkingOfficeName = "Default Parking Office";
        this.customers = new ArrayList<>();
        this.parkingLots = new ArrayList<>();
        this.permitManager = permitManager;
        this.transactionManager = transactionManager;
    }

    public String getParkingOfficeName() {
        return parkingOfficeName;
    }

    public Customer register(String customerId, String name, Address address, String phoneNumber) {
        Customer customer = new Customer(customerId, name, address, phoneNumber);
        customers.add(customer);
        return customer;
    }

    public ParkingPermit register(Car car) {
        return permitManager.register(car);  // ✅ Fixed this line
    }

    public ParkingTransaction park(Calendar date, ParkingPermit permit, ParkingLot lot) {
        return transactionManager.park(date, permit, lot);
    }

    public Money getParkingCharges(ParkingPermit permit) {
        return transactionManager.getParkingCharges(permit);
    }

    public Money getParkingCharges(Customer customer) {
        return transactionManager.getParkingCharges(customer);
    }

    public void addParkingLot(ParkingLot lot) {
        if (!parkingLots.contains(lot)) {
            parkingLots.add(lot);
        }
    }

    public Customer getCustomer(String customerId) {
        for (Customer customer : customers) {
            if (customer.getCustomerId().equals(customerId)) {
                return customer;
            }
        }
        return null;
    }

    public List<String> getCustomerIds() {
        List<String> customerIds = new ArrayList<>();
        for (Customer customer : customers) {
            customerIds.add(customer.getCustomerId());
        }
        return customerIds;
    }

    public List<String> getPermitIds() {
        return permitManager.getAllPermitIds();
    }

    public List<String> getPermitIds(Customer customer) {
        return permitManager.getPermitIdsByCustomer(customer);
    }
    public Customer findCustomer(String firstName, String lastName) {
        return null;
    }
}
