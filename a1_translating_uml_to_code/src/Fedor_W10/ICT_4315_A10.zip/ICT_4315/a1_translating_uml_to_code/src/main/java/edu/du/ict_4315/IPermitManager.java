package edu.du.ict_4315;

import java.util.List;

public interface IPermitManager {
    ParkingPermit register(Car car);
    List<String> getAllPermitIds();
    List<String> getPermitIdsByCustomer(Customer customer);
}