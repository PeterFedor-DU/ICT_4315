package edu.du.ict_4315;

import java.util.Calendar;

public interface ITransactionManager {
    ParkingTransaction park(Calendar date, ParkingPermit permit, ParkingLot lot);
    Money getParkingCharges(ParkingPermit permit);
    Money getParkingCharges(Customer customer);
}
